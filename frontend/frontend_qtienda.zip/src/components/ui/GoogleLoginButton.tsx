"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useGoogleLogin } from "@react-oauth/google";
import toast from "react-hot-toast";
import { apiClient } from "@/lib/api";
import { useAuthStore } from "@/store/authStore";

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden>
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );
}

function Spinner() {
  return (
    <svg className="animate-spin" width="16" height="16" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2.5" aria-hidden>
      <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
    </svg>
  );
}

interface Props {
  label?: string;
  mode?: "vendor" | "buyer";
}

function Inner({ label, mode }: Required<Props>) {
  const router = useRouter();
  const { setTokens, setUser } = useAuthStore();
  const [loading, setLoading] = useState(false);

  const endpoint = mode === "buyer" ? "/auth/google-buyer" : "/auth/google";

  const login = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      setLoading(true);
      try {
        const { data } = await apiClient.post(endpoint, {
          access_token: tokenResponse.access_token,
        });
        setTokens(data.access_token, data.refresh_token);
        const { data: me } = await apiClient.get("/auth/me", {
          headers: { Authorization: `Bearer ${data.access_token}` },
        });
        setUser(me);
        toast.success("¡Bienvenido!");
        if (me.role === "admin")       router.push("/admin");
        else if (me.role === "buyer")  router.push("/mis-pedidos");
        else                           router.push("/dashboard");
      } catch (err: any) {
        toast.error(err.response?.data?.detail || "Error al iniciar con Google");
      } finally {
        setLoading(false);
      }
    },
    onError: () => toast.error("Error al iniciar con Google"),
  });

  return (
    <button
      type="button"
      className="btn-social"
      onClick={() => login()}
      disabled={loading}
    >
      {loading ? <Spinner /> : <GoogleIcon />}
      {loading ? "Conectando..." : label}
    </button>
  );
}

export default function GoogleLoginButton({
  label = "Continuar con Google",
  mode  = "vendor",
}: Props) {
  if (!process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID) return null;
  return <Inner label={label} mode={mode} />;
}
